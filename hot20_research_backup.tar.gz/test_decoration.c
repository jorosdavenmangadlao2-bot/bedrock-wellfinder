#include <stdio.h>
#include <stdint.h>
#include "mt.h"

int main(void)
{
    uint64_t worldSeed = 1520815389707ULL;
    int chunkX = 676297;
    int chunkZ = -479950;
    int salt = -1160484816;

    uint32_t decorationSeed =
        setDecorationSeed(worldSeed, chunkX, chunkZ, salt);

    int gate = nextInt(500);
    int z = nextInt(16);
    int x = nextInt(16);

    printf("WORLD SEED       : %llu\n",
           (unsigned long long)worldSeed);
    printf("CHUNK            : (%d, %d)\n", chunkX, chunkZ);
    printf("SALT             : %d\n", salt);
    printf("DECORATION SEED  : %u\n", decorationSeed);
    printf("GATE             : %d\n", gate);
    printf("LOCAL Z          : %d\n", z);
    printf("LOCAL X          : %d\n", x);

    return 0;
}
