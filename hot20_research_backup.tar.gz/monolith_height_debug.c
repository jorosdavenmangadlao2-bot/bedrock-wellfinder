#include "generator.h"
#include "finders.h"

#include <stdio.h>
#include <stdint.h>

typedef struct {
    int x, y, z;
} Target;

int main(void)
{
    const uint64_t seed = 1520815444168ULL;

    Target t[] = {
        {10820529, 252, -7679331},
        {10820414, 252, -7679592},
        {10820811, 254, -7679431}
    };

    int n = 3;

    Generator g;
    setupGenerator(&g, MC_26_40, 0);
    applySeed(&g, DIM_OVERWORLD, seed);

    SurfaceNoise sn;
    initSurfaceNoise(&sn, DIM_OVERWORLD, seed);

    printf("========================================\n");
    printf(" MONOLITH HEIGHT PROBE\n");
    printf("========================================\n");
    printf("Seed    : %llu\n",
        (unsigned long long)seed);
    printf("Version : MC_26_40\n");
    printf("----------------------------------------\n");

    for (int i = 0; i < n; i++)
    {
        int x = t[i].x;
        int y = t[i].y;
        int z = t[i].z;

        int sx = x >> 2;
        int sz = z >> 2;

        float h = 0.0f;

        mapApproxHeight(
            &h,
            NULL,
            &g,
            &sn,
            sx,
            sz,
            1,
            1
        );

        printf("\nTARGET #%d\n", i + 1);
        printf("Observed : X=%d Y=%d Z=%d\n", x, y, z);
        printf("Sample   : X=%d Z=%d\n", sx, sz);
        printf("Approx H : %.3f\n", h);

        printf("\nBIOME SAMPLES\n");

        int ys[] = {
            64, 96, 128, 160,
            192, 224, 240, 248,
            252, 254, 256
        };

        int yn = sizeof(ys) / sizeof(ys[0]);

        for (int j = 0; j < yn; j++)
        {
            int by = ys[j];

            int biome = getBiomeAt(
                &g,
                4,
                sx,
                by >> 2,
                sz
            );

            printf("Y=%3d -> biome=%d\n",
                by, biome);
        }

        printf("----------------------------------------\n");
    }

    printf("\n========================================\n");
    printf(" PROBE COMPLETE\n");
    printf("========================================\n");

    return 0;
}
