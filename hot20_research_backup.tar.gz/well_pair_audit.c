#include <stdio.h>
#include <stdint.h>
#include "finders.h"
#include "generator.h"

int main(void)
{
    uint64_t seed = 2780405618978080599ULL;

    int cx[2] = {7336, 7337};
    int cz[2] = {1941, 1941};

    Generator g;
    setupGenerator(&g, MC_26_40, 0);
    applySeed(&g, DIM_OVERWORLD, seed);

    printf("========================================\n");
    printf(" 4TH CANDIDATE WELL AUDIT\n");
    printf("========================================\n");
    printf("Seed: %llu\n", (unsigned long long)seed);
    printf("----------------------------------------\n");

    for (int i = 0; i < 2; i++)
    {
        Pos p;

        int generated = getStructurePos(
            Desert_Well,
            MC_26_40,
            seed,
            cx[i],
            cz[i],
            &p
        );

        printf("\nWell %d\n", i + 1);
        printf("Chunk      : (%d, %d)\n", cx[i], cz[i]);

        if (!generated)
        {
            printf("RNG result : NO WELL CANDIDATE\n");
            continue;
        }

        printf("Candidate  : (%d, %d)\n", p.x, p.z);

        int viable = isViableStructurePos(
            Desert_Well,
            &g,
            p.x,
            p.z,
            0
        );

        printf("Viable     : %s\n",
               viable ? "YES" : "NO");
    }

    printf("\n========================================\n");

    return 0;
}
