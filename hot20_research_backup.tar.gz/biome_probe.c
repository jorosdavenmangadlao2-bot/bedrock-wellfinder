#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "generator.h"
#include "biomenoise.h"

int main(int argc, char **argv)
{
    if (argc != 4)
    {
        fprintf(stderr, "Usage: %s <seed> <x> <z>\n", argv[0]);
        return 1;
    }

    int64_t seed = strtoll(argv[1], NULL, 10);
    int x = atoi(argv[2]);
    int z = atoi(argv[3]);

    BiomeNoise bn;

    initBiomeNoise(&bn, MC_1_18);
    setBiomeSeed(&bn, (uint64_t)seed, 0);

    int64_t np[6] = {0};

    int biome = sampleBiomeNoise(
        &bn,
        np,
        x, 0, z,
        NULL,
        0
    );

    printf("========================================\n");
    printf(" Bedrock Biome Probe\n");
    printf("========================================\n");
    printf("Seed : %lld\n", (long long)seed);
    printf("X    : %d\n", x);
    printf("Z    : %d\n", z);
    printf("----------------------------------------\n");

    printf("Biome ID       : %d\n", biome);

    printf("----------------------------------------\n");
    printf("Climate\n");
    printf("Temperature    : %.7f\n", np[0] / 10000.0);
    printf("Humidity       : %.7f\n", np[1] / 10000.0);
    printf("Continentalness: %.7f\n", np[2] / 10000.0);
    printf("Erosion        : %.7f\n", np[3] / 10000.0);
    printf("Depth          : %.7f\n", np[4] / 10000.0);
    printf("Weirdness      : %.7f\n", np[5] / 10000.0);

    return 0;
}
