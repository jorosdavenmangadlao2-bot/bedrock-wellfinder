#include "generator.h"
#include "biomenoise.h"
#include <stdio.h>
#include <stdint.h>

int main(void)
{
    uint64_t seed = 1520815389707ULL;

    Generator g;
    SurfaceNoise sn;

    setupGenerator(&g, MC_26_40, 0);
    applySeed(&g, DIM_OVERWORLD, seed);
    initSurfaceNoise(&sn, DIM_OVERWORLD, seed);

    int x = 10820752;
    int z = -7679200;

    float y;
    int biome_id;

    mapApproxHeight(
        &y,
        &biome_id,
        &g,
        &sn,
        x >> 2,
        z >> 2,
        1,
        1
    );

    printf("========================================\n");
    printf(" SURFACE Y TEST\n");
    printf("========================================\n");
    printf("Seed       : %llu\n",
        (unsigned long long)seed);
    printf("Block X    : %d\n", x);
    printf("Block Z    : %d\n", z);
    printf("Sample X   : %d\n", x >> 2);
    printf("Sample Z   : %d\n", z >> 2);
    printf("Biome ID   : %d\n", biome_id);
    printf("Approx Y   : %.3f\n", y);
    printf("========================================\n");

    return 0;
}
