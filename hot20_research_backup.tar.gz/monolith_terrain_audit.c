#include "generator.h"
#include "finders.h"

#include <stdio.h>
#include <stdint.h>
#include <math.h>

typedef struct {
    int x;
    int y;
    int z;
} Target;

int main(void)
{
    const uint64_t seed = 1520815444168ULL;

    Target targets[] = {
        {10820529, 252, -7679331},
        {10820414, 252, -7679592},
        {10820811, 254, -7679431}
    };

    int count = sizeof(targets) / sizeof(targets[0]);

    Generator g;
    setupGenerator(&g, MC_26_40, 0);
    applySeed(&g, DIM_OVERWORLD, seed);

    SurfaceNoise sn;
    initSurfaceNoise(&sn, DIM_OVERWORLD, seed);

    printf("========================================\n");
    printf(" BEDROCK MONOLITH TERRAIN AUDIT\n");
    printf("========================================\n");
    printf("Seed       : %llu\n",
        (unsigned long long)seed);
    printf("Version    : MC_26_40\n");
    printf("Targets    : %d\n", count);
    printf("----------------------------------------\n");

    for (int i = 0; i < count; i++)
    {
        int bx = targets[i].x;
        int by = targets[i].y;
        int bz = targets[i].z;

        int sx = bx >> 2;
        int sz = bz >> 2;

        int biome = getBiomeAt(
            &g,
            4,
            sx,
            0,
            sz
        );

        float height = 0.0f;

        mapApproxHeight(
            &height,
            NULL,
            &g,
            &sn,
            sx,
            sz,
            1,
            1
        );

        printf("TARGET #%d\n", i + 1);
        printf("Observed X  : %d\n", bx);
        printf("Observed Y  : %d\n", by);
        printf("Observed Z  : %d\n", bz);
        printf("Sample      : (%d,%d)\n", sx, sz);
        printf("Biome ID    : %d\n", biome);
        printf("Approx Y    : %.3f\n", height);

        printf("Delta Y     : %.3f\n",
            height - (float)by);

        if (height >= 240.0f)
            printf("HIGH TERRAIN: PASS\n");
        else
            printf("HIGH TERRAIN: FAIL\n");

        printf("----------------------------------------\n");
    }

    printf("========================================\n");
    printf(" AUDIT COMPLETE\n");
    printf("========================================\n");

    return 0;
}
