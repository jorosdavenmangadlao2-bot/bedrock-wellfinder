#include "generator.h"
#include "finders.h"
#include <stdio.h>

int main(void)
{
    Generator g;

    setupGenerator(&g, MC_26_40, 0);
    applySeed(&g, DIM_OVERWORLD, 1520815389707ULL);

    printf("Generator initialization OK\n");
    printf("MC version: MC_26_40\n");
    printf("Seed: %llu\n",
        (unsigned long long)g.seed);

    return 0;
}
