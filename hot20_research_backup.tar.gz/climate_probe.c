#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "generator.h"
#include "biomenoise.h"

int main(int argc, char **argv)
{
    if (argc != 4)
    {
        fprintf(stderr, "Usage: %s <seed> <x> <z>\n", argv[0]);
        return 1;
    }

    int64_t seed = strtoll(argv[1], NULL, 10);
    int x = atoi(argv[2]);
    int z = atoi(argv[3]);

    BiomeNoise bn;

    /*
     * IMPORTANT:
     * Initialize the biome spline stack before sampling.
     */
    initBiomeNoise(&bn, MC_1_18);

    /*
     * Initialize modern climate noise.
     * LARGE_BIOMES disabled.
     */
    setBiomeSeed(&bn, (uint64_t)seed, 0);

    int64_t np[6] = {0};

    /*
     * Full climate sampling.
     */
    bn.nptype = -1;

    sampleBiomeNoise(
        &bn,
        np,
        x, 0, z,
        NULL,
        SAMPLE_NO_BIOME
    );

    printf("========================================\n");
    printf(" Bedrock Climate Probe\n");
    printf("========================================\n");
    printf("Seed : %lld\n", (long long)seed);
    printf("X    : %d\n", x);
    printf("Z    : %d\n", z);
    printf("----------------------------------------\n");

    printf("Temperature    : %.7f\n", np[0] / 10000.0);
    printf("Humidity       : %.7f\n", np[1] / 10000.0);
    printf("Continentalness: %.7f\n", np[2] / 10000.0);
    printf("Erosion        : %.7f\n", np[3] / 10000.0);
    printf("Depth          : %.7f\n", np[4] / 10000.0);
    printf("Weirdness      : %.7f\n", np[5] / 10000.0);

    printf("----------------------------------------\n");
    printf("RAW\n");
    printf("T=%lld\n", (long long)np[0]);
    printf("H=%lld\n", (long long)np[1]);
    printf("C=%lld\n", (long long)np[2]);
    printf("E=%lld\n", (long long)np[3]);
    printf("D=%lld\n", (long long)np[4]);
    printf("W=%lld\n", (long long)np[5]);

    return 0;
}
