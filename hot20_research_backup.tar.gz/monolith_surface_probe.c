#include "biomenoise.h"
#include <stdio.h>
#include <stdint.h>

typedef struct {
    int x, y, z;
} Target;

int main(void)
{
    const uint64_t seed = 1520815444168ULL;

    Target t[] = {
        {10820529, 252, -7679331},
        {10820414, 252, -7679592},
        {10820811, 254, -7679431}
    };

    SurfaceNoise sn;
    initSurfaceNoise(&sn, DIM_OVERWORLD, seed);

    printf("========================================\n");
    printf(" MONOLITH SURFACE NOISE PROBE\n");
    printf("========================================\n");
    printf("Seed    : %llu\n", (unsigned long long)seed);
    printf("Version : MC_26_40\n");
    printf("----------------------------------------\n");

    for (int i = 0; i < 3; i++)
    {
        printf("\nTARGET #%d\n", i + 1);
        printf("X=%d Y=%d Z=%d\n", t[i].x, t[i].y, t[i].z);
        printf("----------------------------------------\n");

        for (int y = 0; y <= 256; y += 8)
        {
            double n = sampleSurfaceNoise(
                &sn,
                t[i].x,
                y,
                t[i].z
            );

            printf("Y=%3d  Noise=% .9f\n", y, n);
        }
    }

    printf("\n========================================\n");
    printf(" PROBE COMPLETE\n");
    printf("========================================\n");

    return 0;
}
