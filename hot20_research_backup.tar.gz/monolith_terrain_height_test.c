#include "generator.h"
#include "finders.h"
#include <stdio.h>
#include <stdint.h>

typedef struct
{
    int x;
    int y;
    int z;
} Target;

int main(void)
{
    uint64_t seed = 1520815444168ULL;

    Target targets[] =
    {
        {10820529, 252, -7679331},
        {10820414, 252, -7679592},
        {10820811, 254, -7679431}
    };

    int count = sizeof(targets) / sizeof(targets[0]);

    Generator g;

    setupGenerator(&g, MC_26_40, 0);
    applySeed(&g, DIM_OVERWORLD, seed);

    printf("========================================\n");
    printf(" MONOLITH ACTUAL TERRAIN HEIGHT TEST\n");
    printf("========================================\n");
    printf("Seed    : %llu\n",
           (unsigned long long)seed);
    printf("Version : MC_26_40\n");
    printf("----------------------------------------\n");

    for (int i = 0; i < count; i++)
    {
        int x = targets[i].x;
        int y = targets[i].y;
        int z = targets[i].z;

        int actual_height = getHeightAt(&g, x, z);

        printf("TARGET #%d\n", i + 1);
        printf("----------------------------------------\n");

        printf("Observed X : %d\n", x);
        printf("Observed Y : %d\n", y);
        printf("Observed Z : %d\n", z);

        printf("Actual terrain height : %d\n", actual_height);

        printf("Height delta          : %d\n",
               y - actual_height);

        if (actual_height >= 250)
        {
            printf("HIGH TERRAIN          : PASS\n");
        }
        else
        {
            printf("HIGH TERRAIN          : FAIL\n");
        }

        if (y <= actual_height + 4 && y >= actual_height - 4)
        {
            printf("OBSERVED HEIGHT MATCH : PASS\n");
        }
        else
        {
            printf("OBSERVED HEIGHT MATCH : FAIL\n");
        }

        printf("----------------------------------------\n");
    }

    printf("========================================\n");
    printf(" HEIGHT TEST COMPLETE\n");
    printf("========================================\n");

    return 0;
}
