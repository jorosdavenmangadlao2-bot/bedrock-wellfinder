#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

static int random_seed64(int64_t *out)
{
    FILE *fp = fopen("/dev/urandom", "rb");

    if (fp)
    {
        uint64_t bits;

        if (fread(&bits, sizeof(bits), 1, fp) == 1)
        {
            fclose(fp);
            *out = (int64_t)bits;
            return 1;
        }

        fclose(fp);
    }

    uint64_t bits = 0;

    bits |= ((uint64_t)(unsigned int)rand()) << 32;
    bits |= (uint64_t)(unsigned int)rand();

    *out = (int64_t)bits;
    return 1;
}

int main(void)
{
    printf("========================================\n");
    printf(" Stage 4B Random Seed Test\n");
    printf("========================================\n");

    for (int i = 0; i < 10; i++)
    {
        int64_t seed;

        if (!random_seed64(&seed))
        {
            printf("ERROR generating seed\n");
            return 1;
        }

        printf("Random seed %2d : %lld\n",
               i + 1,
               (long long)seed);
    }

    printf("========================================\n");

    return 0;
}
